package com.cervonet.furqan.carrobot;

import android.app.Activity;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class MainActivity  extends AppCompatActivity {
    static public byte[] send_data = new byte[1024];
    static public int port = 6668;
    static public String ipAdd = "192.168.1.4";
    static public DatagramSocket client_socket ;
    static public InetAddress IPAddress;
    Button up;
    Button down;
    Button right;
    Button left;
    String value="";

    byte[] receiveData = new byte[1024];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(isInternetOn()==false) {
        Intent intent_start_wifi = new Intent(Settings.ACTION_WIFI_SETTINGS);
        startActivity(intent_start_wifi);

    }
        up=(Button)findViewById(R.id.up);
        down=(Button)findViewById(R.id.down);
        right=(Button)findViewById(R.id.right);
        left=(Button)findViewById(R.id.left);
        up.setOnTouchListener(tch1);
        down.setOnTouchListener(tch2);
        right.setOnTouchListener(tch3);
        left.setOnTouchListener(tch4);
        try {
            client_socket = new DatagramSocket(port);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        try {
            IPAddress = InetAddress.getByName(ipAdd);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }


    }


    Button.OnTouchListener tch1 = new Button.OnTouchListener()

    {


        @Override
        public boolean onTouch(View v, MotionEvent event) {


            switch ( event.getAction() ) {
                case MotionEvent.ACTION_DOWN:
                    value = "1";
                    break;
                case MotionEvent.ACTION_UP:
                    value = "0";
                    Log.e("i","touch 1");
                    break;
            }

            try {

                Sending();

                // Toast.makeText(MainActivity.this," main str is called : "+mainStr+"",Toast.LENGTH_LONG).show();

            } catch (IOException e) {
                e.printStackTrace();
            }


            return true;
        }
    };

    Button.OnTouchListener tch2 = new Button.OnTouchListener()

    {


        @Override
        public boolean onTouch(View v, MotionEvent event) {


            switch ( event.getAction() ) {
                case MotionEvent.ACTION_DOWN:
                    value = "2";
                    break;
                case MotionEvent.ACTION_UP:
                    value = "0";
                    Log.e("i","touch 2");
                    break;
            }
            try {

                Sending();

                // Toast.makeText(MainActivity.this," main str is called : "+mainStr+"",Toast.LENGTH_LONG).show();

            } catch (IOException e) {
                e.printStackTrace();
            }


            return true;
        }
    };


    Button.OnTouchListener tch3 = new Button.OnTouchListener()

    {


        @Override
        public boolean onTouch(View v, MotionEvent event) {


            switch ( event.getAction() ) {
                case MotionEvent.ACTION_DOWN:
                    value = "3";
                    break;
                case MotionEvent.ACTION_UP:
                    Log.e("i","touch 3");
                    value = "0";
                    break;
            }
            try {

                Sending();

                // Toast.makeText(MainActivity.this," main str is called : "+mainStr+"",Toast.LENGTH_LONG).show();

            } catch (IOException e) {
                e.printStackTrace();
            }


            return true;
        }
    };


    Button.OnTouchListener tch4 = new Button.OnTouchListener()

    {


        @Override
        public boolean onTouch(View v, MotionEvent event) {


            switch ( event.getAction() ) {
                case MotionEvent.ACTION_DOWN:
                     value = "4";
                    break;
                case MotionEvent.ACTION_UP:
                    Log.e("i","touch 4");
                    value = "0";
                    break;
            }
            try {

                Sending();

                // Toast.makeText(MainActivity.this," main str is called : "+mainStr+"",Toast.LENGTH_LONG).show();

            } catch (IOException e) {
                e.printStackTrace();
            }



            return true;
        }
    };



    public void Receiving()
    {
        new Thread(){
            @Override
            public void run() {
                while(true)
                {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    try {
                        client_socket.receive(receivePacket);
                        Log.e("Received", "Data..............."+ new String(receivePacket.getData()).substring(0,receivePacket.getLength()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
        }.start();
    }


    public void Sending() throws IOException {
        // dat= "";
        Log.e("Send", "in Client thread");

            Thread t2 = new Thread() {
                @Override
                public void run() {
                    send_data = value.getBytes();
                    DatagramPacket send_packet = new DatagramPacket(send_data, value.length(), IPAddress, port);
                    Log.e("Send", "furqan");


                    Log.e("Send", "Data...." + value + "");
                    try {
                        client_socket.send(send_packet);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }



                }
            };
            t2.start();
            try {
                t2.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //  dat = "";


    }
    public final boolean isInternetOn() {

        // get Connectivity Manager object to check connection
        ConnectivityManager connec = (ConnectivityManager)getSystemService(getBaseContext().CONNECTIVITY_SERVICE);

        // Check for network connections
        if ( connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.CONNECTED ||
                connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.CONNECTING ||
                connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTING ||
                connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTED ) {

            // if connected with internet

            Toast.makeText(this, " Connected ", Toast.LENGTH_LONG).show();
            return true;

        } else if (
                connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.DISCONNECTED ||
                        connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.DISCONNECTED  ) {

            Toast.makeText(this, " Not Connected ", Toast.LENGTH_LONG).show();
            return false;
        }
        return false;
    }

}
